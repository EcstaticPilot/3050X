#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor LeftFrontMotor1 = motor(PORT1, ratio18_1, false);
motor LeftBackMotor7 = motor(PORT7, ratio18_1, false);
motor RightFrontMotor8 = motor(PORT8, ratio18_1, false);
motor RightBackMotor14 = motor(PORT14, ratio18_1, false);
motor LeftIntake3 = motor(PORT3, ratio18_1, false);
motor RightIntake10 = motor(PORT10, ratio18_1, false);
controller Controller1 = controller(primary);
motor LeftTopIntake5 = motor(PORT5, ratio18_1, false);
motor RightTopIntake12 = motor(PORT12, ratio18_1, false);
inertial GyroSpin = inertial(PORT11);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}