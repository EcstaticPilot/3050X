/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Gary                                             */
/*    Created:      Tue Sep 29 2020                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LeftFrontMotor1      motor         1               
// LeftBackMotor7       motor         7               
// RightFrontMotor8     motor         8               
// RightBackMotor14     motor         14              
// LeftIntake3          motor         3               
// RightIntake10        motor         10              
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

void driverControl () {

  while(true){

  LeftFrontMotor1.spin(forward, Controller1.Axis3.position(pct), pct);
  LeftBackMotor7.spin(forward, Controller1.Axis3.position(pct), pct);
  RightFrontMotor8.spin(forward, Controller1.Axis2.position(pct), pct);
  RightBackMotor14.spin(forward, Controller1.Axis2.position(pct), pct);

  if(Controller1.ButtonR1.pressing()){

   LeftIntake3.spin(forward, 85, pct);
   RightIntake10.spin(forward, 85, pct);
  }
  else if(Controller1.ButtonR2.pressing()){
    
    LeftIntake3.spin(reverse, 85, pct);
    RightIntake10.spin(reverse, 85, pct);
  }
  else{
    LeftIntake3.stop(brake);
    RightIntake10.stop(brake);
  }


  }
} 


int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  driverControl();
  
}
