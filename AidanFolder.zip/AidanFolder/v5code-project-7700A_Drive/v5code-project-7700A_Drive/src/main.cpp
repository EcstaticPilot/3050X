/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\dmcsc                                            */
/*    Created:      Sun Jul 26 2020                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// RB                   motor         13              
// LB                   motor         2               
// RF                   motor         11              
// LF                   motor         20              
// Controller1          controller                    
// Lift                 motor         12              
// Intake               motor         3               
// ---- END VEXCODE CONFIGURED DEVICES ----
float PI = 3.1415;
float D = 4.065;
#include "vex.h"

using namespace vex;
//Functions
void keepdriving(int lspeed, int rspeed){   
LF.spin(fwd, lspeed, percent);
LB.spin(fwd, lspeed, percent);
RF.spin(fwd, rspeed, percent);
RB.spin(fwd, rspeed, percent);
}

void driver(int lspeed, int rspeed, int t){   
LF.spin(fwd, lspeed, percent);
LB.spin(fwd, lspeed, percent);
RF.spin(fwd, rspeed, percent);
RB.spin(fwd, rspeed, percent);
wait(t, msec);
LF.stop();
LB.stop();
RF.stop();
RB.stop();
}
void InchDrive(int target){
float currentRB = 0;
float currentRF = 0;
float currentLF = 0;
float currentLB = 0;
float kp = 4;
float error = target;
while(error > 1) {
  currentRB = PI * D * RB.position(deg) / 360;
  currentRF = PI * D * RF.position(deg) / 360;
  currentLF = PI * D * LF.position(deg) / 360;  
  currentLB = PI * D * LB.position(deg) / 360;
  error = target - currentRB;
  keepdriving(error*kp, error*kp);
  wait (10, msec);
}
}
  void PreAuton()
  {
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(10, 40, 1, "Pre Auton");
  }

  void Auton()
{
  Brain.Screen.clearScreen();
Brain.Screen.printAt(10, 40, 1, "Auton");
InchDrive(36);
driver(100, -100, 800);
Lift.spin(fwd, 100, percent);
wait(1000, msec);
Lift.stop();
InchDrive(36);
Intake.spin(fwd, 20000, percent);
wait(1000, msec);
Intake.stop();
}
void driverControl()
{
  float lspeed = 0;
  float rspeed = 0;
  float speed = 1.0;
  Brain.Screen.clearScreen();
  Brain.Screen.printAt(10, 40, 1, "Driving");
  while(true){
  if(Controller1.ButtonDown.pressing()){
    speed = 0.5;
  }
    if(Controller1.ButtonLeft.pressing()){
    speed = 1;
  }
    if(Controller1.ButtonUp.pressing()){
    speed = 1.5;
  }
    if(Controller1.ButtonRight.pressing()){
    speed = 2;
  }
    if(abs(Controller1.Axis3.position())<=50)
    {
      speed = 0.5;
    }
    else
    {
     speed = 1;
    }
    lspeed=Controller1.Axis3.position()*Controller1.Axis3.position()/100;
    rspeed=Controller1.Axis2.position()*Controller1.Axis2.position()/100;
    driver(lspeed, rspeed, 10);
}
}



int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
 PreAuton();
 Auton();
 driverControl();
 
}
