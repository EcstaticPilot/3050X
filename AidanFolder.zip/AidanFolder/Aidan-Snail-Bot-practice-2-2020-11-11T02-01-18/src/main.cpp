/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Gary                                             */
/*    Created:      Tue Sep 29 2020                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LeftFrontMotor1      motor         1               
// LeftBackMotor7       motor         7               
// RightFrontMotor8     motor         8               
// RightBackMotor14     motor         14              
// LeftIntake3          motor         3               
// RightIntake10        motor         10              
// Controller1          controller                    
// LeftTopRoller5       motor         5               
// RightTopRoller12     motor         12              
// GyroSpin             inertial      11              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <iostream>
using namespace vex;
using std::cout;
using std::endl;
//gloabal variable
float dia = 4.0;

void autonDrive(float Rspeed, float Lspeed, int wt){

}

void GyroTurn(float target){

}

void intakeAuton(float speed, int wt){
  //should be 
}


//this is GUI: Graphic User Interface
void draw(){
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(240, 136, 100, 50);

  Brain.Screen.setFillColor(red);
  Brain.Screen.setPenColor(white);
  Brain.Screen.drawRectangle(10, 10, 100, 50);
  Brain.Screen.printAt(160, 60, "Annotations are very important");


  Brain.Screen.setFillColor(blue);
  Brain.Screen.setPenColor(white);
  Brain.Screen.drawRectangle(400, 10, 100, 50);
  Brain.Screen.setPenColor(green);
  Brain.Screen.printAt(410, 15, "C++");


  Brain.Screen.printAt(400, 20, "Motor Temprature %f", LeftFrontMotor1.temperature(pct)); 
  Brain.Screen.printAt(400, 20, "Motor Temprature %f", LeftBackMotor7.temperature(pct));
  Brain.Screen.printAt(400, 20, "Motor Temprature %f", RightFrontMotor8.temperature(pct));
  Brain.Screen.printAt(400, 20, "Motor Temprature %f", RightBackMotor14.temperature(pct));
  Brain.Screen.printAt(400, 20, "Motor Temprature %f", LeftIntake3.temperature(pct));
  Brain.Screen.printAt(400, 20, "Motor Temprature %f", RightIntake10.temperature(pct));
  Brain.Screen.printAt(400, 20, "Motor Temprature %f", LeftTopRoller5.temperature(pct));
  Brain.Screen.printAt(400, 20, "Motor Temprature %f", RightTopRoller12.temperature(pct));
  wait(500, msec);
  Brain.Screen.clearScreen();
}
void InchDrive(float target, int Lspeed, int Rspeed) {

  int x = 0;

  while (x <= target){

    LeftBackMotor7.spin(forward,Lspeed, pct);
    RightBackMotor14.spin(forward,Rspeed, pct);
    LeftFrontMotor1.spin(forward,Lspeed, pct);
    RightFrontMotor8.spin(forward,Rspeed, pct);

    x = LeftBackMotor7.rotation(rev)*3.14*dia;
  }
LeftBackMotor7.stop(brake);
RightBackMotor14.stop(brake);
LeftFrontMotor1.stop(brake);
RightFrontMotor8.stop(brake);
}

void driverControl() {

  while (true) { 

    LeftFrontMotor1.spin(forward, Controller1.Axis3.position(pct), pct);
    LeftBackMotor7.spin(forward, Controller1.Axis3.position(pct), pct);
    RightFrontMotor8.spin(forward, Controller1.Axis2.position(pct), pct);
    RightBackMotor14.spin(forward, Controller1.Axis2.position(pct), pct);

    if (Controller1.ButtonR1.pressing()) {

      LeftIntake3.spin(forward, 85, pct);
      RightIntake10.spin(forward, 85, pct);
    } else if (Controller1.ButtonR2.pressing()) {

      LeftIntake3.spin(reverse, 85, pct);
      RightIntake10.spin(reverse, 85, pct);
    } else {
      LeftIntake3.stop(brake);
      RightIntake10.stop(brake);
    }

    if (Controller1.ButtonL1.pressing()) {

      LeftTopRoller5.spin(forward, 85, pct);
      RightTopRoller12.spin(forward, 85, pct);
    } else if (Controller1.ButtonL2.pressing()) {

      LeftTopRoller5.spin(reverse, 85, pct);
      RightTopRoller12.spin(reverse, 85, pct);
    } else {
      LeftTopRoller5.stop(brake);
      RightTopRoller12.stop(brake);
    }

    void preAuton();
    { cout << " " << endl; }
  }
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  draw();
  InchDrive(25,50,50);
  driverControl();
}
