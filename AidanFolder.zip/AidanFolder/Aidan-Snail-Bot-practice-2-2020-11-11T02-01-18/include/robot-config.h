using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor LeftFrontMotor1;
extern motor LeftBackMotor7;
extern motor RightFrontMotor8;
extern motor RightBackMotor14;
extern motor LeftIntake3;
extern motor RightIntake10;
extern controller Controller1;
extern motor LeftTopRoller5;
extern motor RightTopRoller12;
extern inertial GyroSpin;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );