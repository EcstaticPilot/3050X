/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Gary                                             */
/*    Created:      Tue Sep 29 2020                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LeftFrontMotor1      motor         1
// LeftBackMotor7       motor         7
// RightFrontMotor8     motor         8
// RightBackMotor14     motor         14
// LeftIntake3          motor         3
// RightIntake10        motor         10
// Controller1          controller
// LeftTopIntake5       motor         5
// RightTopIntake12     motor         12
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <iostream>
using namespace vex;
using std::cout;
using std::endl;

float dia = 4.0;

void InchDrive(float target, int speed) {

  int x = 0;

  while (x <= target){

    LeftBackMotor7.spin(forward,speed, pct);
    RightBackMotor14.spin(forward,speed, pct);
    LeftFrontMotor1.spin(forward,speed, pct);
    RightFrontMotor8.spin(forward,speed, pct);

    x = LeftBackMotor7.rotation(rev)*3.14*dia;
  }
LeftBackMotor7.stop(brake);
RightBackMotor14.stop(brake);
LeftFrontMotor1.stop(brake);
RightFrontMotor8.stop(brake);
}

void driverControl() {

  while (true) { 

    LeftFrontMotor1.spin(forward, Controller1.Axis3.position(pct), pct);
    LeftBackMotor7.spin(forward, Controller1.Axis3.position(pct), pct);
    RightFrontMotor8.spin(forward, Controller1.Axis2.position(pct), pct);
    RightBackMotor14.spin(forward, Controller1.Axis2.position(pct), pct);

    if (Controller1.ButtonR1.pressing()) {

      LeftIntake3.spin(forward, 85, pct);
      RightIntake10.spin(forward, 85, pct);
    } else if (Controller1.ButtonR2.pressing()) {

      LeftIntake3.spin(reverse, 85, pct);
      RightIntake10.spin(reverse, 85, pct);
    } else {
      LeftIntake3.stop(brake);
      RightIntake10.stop(brake);
    }

    if (Controller1.ButtonL1.pressing()) {

      LeftTopIntake5.spin(forward, 85, pct);
      RightTopIntake12.spin(forward, 85, pct);
    } else if (Controller1.ButtonL2.pressing()) {

      LeftTopIntake5.spin(reverse, 85, pct);
      RightTopIntake12.spin(reverse, 85, pct);
    } else {
      LeftTopIntake5.stop(brake);
      RightTopIntake12.stop(brake);
    }

    void preAuton();
    { cout << " " << endl; }
  }
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  InchDrive(25,50);
  driverControl();
}
